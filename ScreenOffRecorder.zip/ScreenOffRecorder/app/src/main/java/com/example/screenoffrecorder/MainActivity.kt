package com.example.screenoffrecorder

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var rbFront: RadioButton
    private lateinit var cbAudio: CheckBox

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val required = requiredPermissions()
            val allGranted = required.all { isGranted(it) }
            if (allGranted) {
                startRecording()
            } else {
                Toast.makeText(this, "Izin kamera/mikrofon diperlukan", Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rbFront = findViewById(R.id.rbFront)
        cbAudio = findViewById(R.id.cbAudio)

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            val missing = allPermissions().filter { !isGranted(it) }
            if (missing.isEmpty()) {
                startRecording()
            } else {
                permissionLauncher.launch(missing.toTypedArray())
            }
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            startService(
                Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP)
            )
        }
    }

    // Izin yang wajib untuk merekam (notifikasi tidak wajib)
    private fun requiredPermissions(): List<String> {
        val list = mutableListOf(Manifest.permission.CAMERA)
        if (cbAudio.isChecked) list += Manifest.permission.RECORD_AUDIO
        return list
    }

    private fun allPermissions(): List<String> {
        val list = requiredPermissions().toMutableList()
        if (Build.VERSION.SDK_INT >= 33) list += Manifest.permission.POST_NOTIFICATIONS
        return list
    }

    private fun isGranted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun startRecording() {
        val intent = Intent(this, RecordService::class.java).apply {
            action = RecordService.ACTION_START
            putExtra(RecordService.EXTRA_FRONT, rbFront.isChecked)
            putExtra(RecordService.EXTRA_AUDIO, cbAudio.isChecked)
        }
        // Harus dipanggil saat app terlihat (foreground) agar kamera boleh diakses service
        ContextCompat.startForegroundService(this, intent)
        Toast.makeText(this, "Merekam... kunci layar sekarang", Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }
}
