package com.example.screenoffrecorder

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.PowerManager
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordService : LifecycleService() {

    companion object {
        const val ACTION_START = "com.example.screenoffrecorder.START"
        const val ACTION_STOP = "com.example.screenoffrecorder.STOP"
        const val EXTRA_FRONT = "extra_front"
        const val EXTRA_AUDIO = "extra_audio"
        private const val CHANNEL_ID = "record_channel"
        private const val NOTIF_ID = 1001
        private const val TAG = "RecordService"
    }

    private var recording: Recording? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var isStarting = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_STOP) {
            stopRecording()
            return START_NOT_STICKY
        }

        if (recording != null || isStarting) return START_NOT_STICKY

        val useFront = intent?.getBooleanExtra(EXTRA_FRONT, false) ?: false
        val withAudio = intent?.getBooleanExtra(EXTRA_AUDIO, true) ?: true

        startAsForeground(withAudio)
        acquireWakeLock()
        startRecording(useFront, withAudio)
        return START_NOT_STICKY
    }

    private fun startAsForeground(withAudio: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Perekaman", NotificationManager.IMPORTANCE_LOW)
        )

        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, RecordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Sedang merekam video")
            .setContentText("Ketuk Stop untuk mengakhiri")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopIntent)
            .build()

        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (withAudio) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE

        ServiceCompat.startForeground(this, NOTIF_ID, notification, type)
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ScreenOffRecorder::Rec").apply {
            acquire(4 * 60 * 60 * 1000L) // maksimal 4 jam
        }
    }

    @SuppressLint("MissingPermission")
    private fun startRecording(useFront: Boolean, withAudio: Boolean) {
        isStarting = true
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider

                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.from(
                            Quality.HD,
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .build()
                val videoCapture = VideoCapture.withOutput(recorder)

                val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
                else CameraSelector.DEFAULT_BACK_CAMERA

                provider.unbindAll()
                provider.bindToLifecycle(this, selector, videoCapture)

                val name = "REC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ScreenOffRecorder")
                }
                val options = MediaStoreOutputOptions.Builder(
                    contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                ).setContentValues(values).build()

                var pending = recorder.prepareRecording(this, options)
                if (withAudio) pending = pending.withAudioEnabled()

                recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                    if (event is VideoRecordEvent.Finalize) {
                        if (event.hasError()) {
                            Log.e(TAG, "Rekaman error: ${event.error}")
                            Toast.makeText(this, "Rekaman berhenti (error ${event.error})", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this, "Video tersimpan di Movies/ScreenOffRecorder", Toast.LENGTH_LONG).show()
                        }
                        recording = null
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Gagal memulai rekaman", e)
                Toast.makeText(this, "Gagal memulai: ${e.message}", Toast.LENGTH_LONG).show()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } finally {
                isStarting = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopRecording() {
        val active = recording
        if (active != null) {
            active.stop() // Finalize event akan memanggil stopSelf()
        } else {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        recording?.stop()
        recording = null
        cameraProvider?.unbindAll()
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
